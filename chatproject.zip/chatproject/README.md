# Zentra — Private Liquid LAN Chat

A private, local-network chat application built for the Zentra project.

## Highlights

- Liquid-glass responsive interface
- Android/iOS touch-first navigation
- LAN-wide group chat
- Private 1-to-1 conversations
- WebSocket live messaging
- Typing indicators
- File sharing (up to 25 MB per file)
- Emoji picker
- Profile username and optional profile logo **after entering the app**
- Adjustable glass blur/clarity
- Animated multi-color background
- Themes and night mode
- Dynamic Island-style status capsule
- Live server capacity panel
- Hard server-side limit of **50 simultaneous users**
- Session-aware reconnect handling
- Mobile safe-area and dynamic viewport support

## Run

```bash
pip install -r requirements.txt
python server.py
```

When the server starts, the host is prompted to set and confirm a room password
of at least 8 characters. Guests enter that password with their name. The server
keeps a salted password verifier in memory; it does not store the plain password.
For unattended starts, set the `ZENTRA_PASSWORD` environment variable before
running `python server.py`.

Over plain `http://` on a LAN, the room password is not encrypted in transit.
Use HTTPS/WSS on networks where traffic may be monitored.

Open:

```text
http://127.0.0.1:8000
```

For another device on the same LAN:

```text
http://YOUR-PC-IP:8000
```

## Project structure

```text
chatproject/
├── server.py
├── requirements.txt
├── README.md
├── LICENSE
└── static/
    └── index.html
```

`chat.db` and `shared_files/` are created at runtime and should not be committed.

## Mobile behavior

The UI does not rely on hover for navigation. The sidebar supports:

- explicit Back/Close control
- touch-friendly buttons
- left-edge swipe to open
- swipe left to close
- safe-area padding
- dynamic viewport sizing for mobile keyboards

The message composer is designed to remain visible when the Android/iOS keyboard opens.

## User identity

The initial entry screen asks for a username and the room password. This avoids
sending large image payloads through the WebSocket during connection.

After entering Zentra, users can add or change their profile logo from the profile/settings panel.

## Copyright

Copyright © 2026 Jenish Rathod. All rights reserved.

Zentra is an original project by Jenish Rathod. See `LICENSE` for the repository license terms.

---

© 2026 Jenish Rathod • Zentra
