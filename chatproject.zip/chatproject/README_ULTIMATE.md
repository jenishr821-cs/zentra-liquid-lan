# Zentra — Ultimate Liquid LAN Edition

## New
- Large premium typography
- Dynamic Island-style live status capsule
- Liquid glass / frosted glass visual system
- Animated aurora background
- 5 complete themes
- Theme persistence
- Private DMs
- Live typing
- Real-time presence
- File sharing up to 25 MB
- Image previews
- Download/open shared files
- Upload progress UI
- File notifications
- SQLite persistence
- Responsive desktop + mobile browser layout
- Single self-contained frontend: `static/index.html`

## Start

```powershell
python -m pip install -r requirements.txt
python server.py
```

Open on server PC:

`http://127.0.0.1:8000`

On another device on the same LAN:

`http://YOUR-PC-IP:8000`

Files are stored in `shared_files/`.

This is intended for a trusted private LAN. It does not provide end-to-end encryption or internet-grade authentication. Do not expose port 8000 to the public internet.
