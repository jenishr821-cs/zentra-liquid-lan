import asyncio
import json
import mimetypes
import os
import sqlite3
import time
import uuid
import collections
import hashlib
import hmac
import getpass
import psutil
from pathlib import Path

from aiohttp import web, WSMsgType


BASE = Path(__file__).resolve().parent
STATIC_DIR = BASE / "static"
UPLOAD_DIR = BASE / "shared_files"
DB = BASE / "chat.db"

HOST = "0.0.0.0"
PORT = 8000
MAX_UPLOAD = 25 * 1024 * 1024  # 25 MB per file
MAX_USERS = 50  # hard server-side connection cap

clients = {}       # websocket -> username
user_sockets = {}  # lowercase username -> websocket
user_avatars = {}  # lowercase username -> data URL (session only)
user_sessions = {}  # lowercase username -> session token
stats_state = {"rx": 0, "tx": 0, "messages": collections.deque(maxlen=1000), "active_uploads": 0}
ROOM_PASSWORD_SALT = None
ROOM_PASSWORD_HASH = None


def configure_room_password():
    """Read the host's room password and retain only a salted verifier."""
    global ROOM_PASSWORD_SALT, ROOM_PASSWORD_HASH
    password = os.environ.get("ZENTRA_PASSWORD")
    if password is None:
        while True:
            password = getpass.getpass("Set Zentra room password (at least 8 characters): ")
            confirm = getpass.getpass("Confirm room password: ")
            if password != confirm:
                print("Passwords do not match. Try again.")
            elif len(password) < 8:
                print("Use at least 8 characters.")
            else:
                break
    elif len(password) < 8:
        raise ValueError("ZENTRA_PASSWORD must be at least 8 characters.")

    ROOM_PASSWORD_SALT = os.urandom(16)
    ROOM_PASSWORD_HASH = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), ROOM_PASSWORD_SALT, 300_000
    )
    del password


def room_password_matches(candidate):
    if ROOM_PASSWORD_HASH is None or ROOM_PASSWORD_SALT is None:
        return False
    candidate_hash = hashlib.pbkdf2_hmac(
        "sha256", str(candidate or "").encode("utf-8"), ROOM_PASSWORD_SALT, 300_000
    )
    return hmac.compare_digest(candidate_hash, ROOM_PASSWORD_HASH)


def db_connect():
    return sqlite3.connect(DB)


def db_init():
    UPLOAD_DIR.mkdir(exist_ok=True)
    con = db_connect()

    con.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT NOT NULL,
            receiver TEXT,
            text TEXT NOT NULL,
            created_at REAL NOT NULL
        )
    """)

    # Upgrade an older chat.db without destroying it.
    columns = {row[1] for row in con.execute("PRAGMA table_info(messages)")}
    upgrades = {
        "kind": "TEXT NOT NULL DEFAULT 'text'",
        "file_name": "TEXT",
        "file_url": "TEXT",
        "file_size": "INTEGER",
        "file_type": "TEXT",
    }
    for name, definition in upgrades.items():
        if name not in columns:
            con.execute(f"ALTER TABLE messages ADD COLUMN {name} {definition}")

    con.commit()
    con.close()


def save_message(sender, receiver, text, kind="text",
                 file_name=None, file_url=None, file_size=None, file_type=None):
    con = db_connect()
    cur = con.execute("""
        INSERT INTO messages
        (sender, receiver, text, created_at, kind, file_name, file_url, file_size, file_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        sender, receiver, text, time.time(), kind,
        file_name, file_url, file_size, file_type
    ))
    message_id = cur.lastrowid
    con.commit()
    con.close()
    return message_id


def load_history(username, limit=150):
    con = db_connect()
    rows = con.execute("""
        SELECT id, sender, receiver, text, created_at,
               COALESCE(kind, 'text'),
               file_name, file_url, file_size, file_type
        FROM messages
        WHERE receiver IS NULL OR receiver = ? OR sender = ?
        ORDER BY id DESC LIMIT ?
    """, (username, username, limit)).fetchall()
    con.close()

    return [
        {
            "id": r[0], "sender": r[1], "receiver": r[2], "text": r[3],
            "created_at": r[4], "kind": r[5],
            "file_name": r[6], "file_url": r[7],
            "file_size": r[8], "file_type": r[9]
        }
        for r in reversed(rows)
    ]


async def send_json(ws, payload):
    if not ws.closed:
        data = json.dumps(payload)
        stats_state["tx"] += len(data.encode("utf-8"))
        await ws.send_str(data)


async def broadcast(payload, exclude=None):
    data = json.dumps(payload)
    stats_state["tx"] += len(data.encode("utf-8")) * max(1, len(clients))
    dead = []
    for ws in list(clients):
        if ws is exclude or ws.closed:
            continue
        try:
            await ws.send_str(data)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.pop(ws, None)


async def send_presence():
    await broadcast({
        "type": "presence",
        "users": sorted(clients.values(), key=str.lower),
        "avatars": {k: v for k, v in user_avatars.items() if k in user_sockets}
    })

async def stats_handler(request):
    now = time.time()
    recent = [t for t in stats_state["messages"] if now - t <= 1.0]
    total_bytes = stats_state["rx"] + stats_state["tx"]
    prev = stats_handler.last_bytes
    stats_handler.last_bytes = total_bytes
    interval = max(0.1, now - stats_handler.last_time)
    stats_handler.last_time = now
    traffic_kbps = max(0, total_bytes - prev) / interval / 1024
    ram = psutil.virtual_memory().percent
    cpu = psutil.cpu_percent(interval=None)
    storage = 0
    if UPLOAD_DIR.exists():
        for f in UPLOAD_DIR.iterdir():
            if f.is_file():
                try: storage += f.stat().st_size
                except OSError: pass
    users = len(clients)
    score = max(cpu, ram, min(100, users * 1.2), min(100, stats_state["active_uploads"] * 12))
    if score >= 85:
        level, warning, icon = "critical", "Server load critical — reduce heavy activity", "🔴"
    elif score >= 70:
        level, warning, icon = "high", "Server load high — heavy traffic detected", "🟠"
    else:
        level, warning, icon = "normal", "Server load normal", "🟢"
    return web.json_response({
        "connected_users": users, "active_websockets": len(clients), "max_users": MAX_USERS,
        "network_kbps": traffic_kbps, "ram_percent": ram,
        "messages_per_sec": len(recent), "active_uploads": stats_state["active_uploads"],
        "storage_bytes": storage, "cpu_percent": cpu,
        "warning_level": level, "warning": warning, "warning_icon": icon
    })

stats_handler.last_bytes = 0
stats_handler.last_time = time.time()


async def index(request):
    return web.FileResponse(STATIC_DIR / "index.html")


async def upload_file(request):
    username = request.headers.get("X-Zentra-User", "").strip()
    if not username or username.lower() not in user_sockets:
        raise web.HTTPUnauthorized(text="Join Zentra before uploading.")

    reader = await request.multipart()
    field = await reader.next()
    if field is None or field.name != "file":
        raise web.HTTPBadRequest(text="Missing file field.")

    original = Path(field.filename or "shared_file").name
    if not original:
        original = "shared_file"

    ext = Path(original).suffix[:12]
    stored = f"{uuid.uuid4().hex}{ext}"
    target = UPLOAD_DIR / stored

    size = 0
    stats_state["active_uploads"] += 1
    try:
        with target.open("wb") as out:
            while True:
                chunk = await field.read_chunk(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_UPLOAD:
                    target.unlink(missing_ok=True)
                    raise web.HTTPRequestEntityTooLarge(
                        max_size=MAX_UPLOAD,
                        actual_size=size
                    )
                out.write(chunk)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    finally:
        stats_state["active_uploads"] = max(0, stats_state["active_uploads"] - 1)

    stats_state["rx"] += size
    content_type = field.headers.get("Content-Type") or mimetypes.guess_type(original)[0] or "application/octet-stream"
    url = f"/shared/{stored}"

    return web.json_response({
        "ok": True,
        "file_name": original,
        "file_url": url,
        "file_size": size,
        "file_type": content_type
    })


async def websocket_handler(request):
    ws = web.WebSocketResponse(heartbeat=25, max_msg_size=64 * 1024)
    await ws.prepare(request)
    username = None

    try:
        async for msg in ws:
            if msg.type != WSMsgType.TEXT:
                continue

            stats_state["rx"] += len(msg.data.encode("utf-8")) if isinstance(msg.data, str) else 0
            try:
                data = json.loads(msg.data)
            except json.JSONDecodeError:
                continue

            event = data.get("type")

            if event == "join":
                if not room_password_matches(data.get("password")):
                    await send_json(ws, {
                        "type": "error",
                        "message": "Incorrect room password. Check with the person hosting Zentra."
                    })
                    continue

                requested = str(data.get("username", "")).strip()
                requested = "".join(
                    c for c in requested if c.isalnum() or c in " _-."
                )[:24].strip()

                if not requested:
                    await send_json(ws, {"type": "error", "message": "Choose a valid username."})
                    continue

                session_id = str(data.get("session_id", "")).strip()[:128]
                key = requested.lower()
                if key in user_sockets:
                    old_session = user_sessions.get(key, "")
                    if session_id and session_id == old_session:
                        old_ws = user_sockets.get(key)
                        if old_ws and old_ws is not ws:
                            clients.pop(old_ws, None)
                            try:
                                await old_ws.close(code=4001, message=b"Session moved to a new connection")
                            except Exception:
                                pass
                    else:
                        await send_json(ws, {"type": "error", "message": "That username is already online."})
                        continue
                elif len(clients) >= MAX_USERS:
                    await send_json(ws, {"type": "error", "message": f"Zentra is full right now. Maximum {MAX_USERS} connected users."})
                    continue

                username = requested
                clients[ws] = username
                user_sockets[key] = ws
                user_sessions[key] = session_id or uuid.uuid4().hex
                await send_json(ws, {
                    "type": "joined",
                    "username": username,
                    "history": load_history(username),
                    "avatars": {k: v for k, v in user_avatars.items() if k in user_sockets}
                })
                await send_presence()
                await broadcast({
                    "type": "system",
                    "text": f"{username} joined the room."
                }, exclude=ws)

            elif not username:
                await send_json(ws, {"type": "error", "message": "Join first."})

            elif event == "profile":
                avatar = str(data.get("avatar", ""))[:1_000_000]
                if avatar.startswith("data:image/"):
                    user_avatars[username.lower()] = avatar
                    await send_presence()

            elif event == "message":
                text = str(data.get("text", "")).strip()
                if not text or len(text) > 2000:
                    continue

                receiver = data.get("receiver")
                receiver = str(receiver).strip() if receiver else None
                if receiver and receiver.lower() == username.lower():
                    receiver = None

                stats_state["messages"].append(time.time())
                msg_id = save_message(username, receiver, text)

                payload = {
                    "type": "message", "id": msg_id, "sender": username,
                    "receiver": receiver, "text": text,
                    "created_at": time.time(), "kind": "text"
                }

                if receiver:
                    target = user_sockets.get(receiver.lower())
                    await send_json(ws, payload)
                    if target:
                        await send_json(target, payload)
                        await send_json(target, {
                            "type": "notification",
                            "title": f"New message from {username}",
                            "text": text[:120]
                        })
                else:
                    await broadcast(payload)

            elif event == "file_message":
                receiver = data.get("receiver")
                receiver = str(receiver).strip() if receiver else None
                if receiver and receiver.lower() == username.lower():
                    receiver = None

                file_name = str(data.get("file_name", "shared_file"))[:255]
                file_url = str(data.get("file_url", ""))[:500]
                file_size = int(data.get("file_size") or 0)
                file_type = str(data.get("file_type", "application/octet-stream"))[:120]

                if not file_url.startswith("/shared/"):
                    continue

                stats_state["messages"].append(time.time())
                msg_id = save_message(
                    username, receiver, file_name, "file",
                    file_name, file_url, file_size, file_type
                )

                payload = {
                    "type": "message", "id": msg_id, "sender": username,
                    "receiver": receiver, "text": file_name,
                    "created_at": time.time(), "kind": "file",
                    "file_name": file_name, "file_url": file_url,
                    "file_size": file_size, "file_type": file_type
                }

                if receiver:
                    target = user_sockets.get(receiver.lower())
                    await send_json(ws, payload)
                    if target:
                        await send_json(target, payload)
                        await send_json(target, {
                            "type": "notification",
                            "title": f"File from {username}",
                            "text": file_name
                        })
                else:
                    await broadcast(payload)

            elif event == "typing":
                receiver = data.get("receiver")
                payload = {
                    "type": "typing", "sender": username,
                    "receiver": receiver, "active": bool(data.get("active"))
                }
                if receiver:
                    target = user_sockets.get(str(receiver).lower())
                    if target:
                        await send_json(target, payload)
                else:
                    await broadcast(payload, exclude=ws)

            elif event == "ping":
                await send_json(ws, {"type": "pong"})

    finally:
        if username:
            key = username.lower()
            # Only clean up the session if this websocket is still the active
            # socket for that username. This prevents an old reconnecting
            # socket from deleting the newly connected session.
            is_current = user_sockets.get(key) is ws
            clients.pop(ws, None)
            if is_current:
                user_sockets.pop(key, None)
                user_avatars.pop(key, None)
                user_sessions.pop(key, None)
                await send_presence()
                await broadcast({
                    "type": "system",
                    "text": f"{username} left the room."
                })

    return ws


async def main():
    configure_room_password()
    db_init()

    print("\n" + "=" * 58)
    print("  ZENTRA • PRIVATE LIQUID LAN")
    print("=" * 58)
    print(f"  Local:  http://127.0.0.1:{PORT}")
    print(f"  LAN:    http://YOUR-LAN-IP:{PORT}")
    print(f"  Files:  {MAX_UPLOAD // (1024 * 1024)} MB max / file")
    print("  Room password: configured")
    print("  WebSocket: /ws")
    print("=" * 58 + "\n")

    app = web.Application(client_max_size=MAX_UPLOAD + 1024 * 1024)
    app.router.add_get("/", index)
    app.router.add_get("/ws", websocket_handler)
    app.router.add_get("/stats", stats_handler)
    app.router.add_post("/upload", upload_file)
    app.router.add_static("/shared/", path=UPLOAD_DIR, name="shared")
    app.router.add_static("/static/", path=STATIC_DIR, name="static")

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, HOST, PORT)
    await site.start()

    while True:
        await asyncio.sleep(3600)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nZentra stopped.")
